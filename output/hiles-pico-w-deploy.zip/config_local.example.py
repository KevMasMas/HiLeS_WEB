"""Copia este archivo como config_local.py y completa los valores localmente.

No subas config_local.py al repositorio.
"""

WIFI_SSID = "CAMBIAR_SSID"
WIFI_PASSWORD = "CAMBIAR_CONTRASENA_WIFI"

MQTT_HOST = "CAMBIAR_IP_DEL_BROKER"
MQTT_PORT = 1883
MQTT_USERNAME = "CAMBIAR_USUARIO_MQTT"
MQTT_PASSWORD = "CAMBIAR_CONTRASENA_MQTT"
MQTT_CLIENT_ID = "pico01"
MQTT_CONNECT_TIMEOUT_SECONDS = 2

# Ritmo cooperativo del motor. No son esperas bloqueantes.
ENGINE_PERIOD_MS = 20
ENGINE_STEP_INTERVAL_MS = 1000
